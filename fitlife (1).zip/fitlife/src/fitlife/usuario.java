/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fitlife;

/**
 *
 * @author Isabella
 */
public class usuario {
   private int idUsuario;
    private String nombre;
    private String correo;
    private String contraseña;
    private int edad;
    private int idAplicacion; 
    
  //constructores//
     public usuario(int idUsuario,String nombre,String correo, String contraseña,int edad,String objetivo,int idAplicacion){
              this.idUsuario =idUsuario;
              this.nombre = nombre;
              this.correo = correo;
              this.contraseña = contraseña;
              this.edad = edad;
              this.idAplicacion = idAplicacion;
     }
              // get y set//
              
            public int getidUsuario(){
                return idUsuario;
              }
            
            public void setidUsuario(){
             
            
     
    
    
    

