package com.mycompany.habitos;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ASUS
 */
public class Estadisticas {
    
    private ArraysList valores;
    private int meta;
    
public Estadisticas(ArrayList valores, int meta) {
    
    this.valores = valores;
    this.meta = meta;
}
    
public int totalValores(){
    return valores.size();
    
}

public int cumplirMeta(){
    int cont = 0;
    for (int v : valores){
        if (v >= meta) cont++;
    }
    return cont;
    
}
 public double porcentajeCumplimiento() {
        if (valores.isEmpty()) return 0;
        return (double) cumplirMeta() / totalValores() * 100;
    }

    public double promedioGeneral() {
        if (valores.isEmpty()) return 0;

        double suma = 0;
        for (int v : valores) suma += v;
        return suma / valores.size();
    }

    public int valorMaximo() {
        if (valores.isEmpty()) return 0;

        int max = valores.get(0);
        for (int v : valores) if (v > max) max = v;
        return max;
    }

    public int valorMinimo() {
        if (valores.isEmpty()) return 0;

        int min = valores.get(0);
        for (int v : valores) if (v < min) min = v;
        return min;
    }


}







