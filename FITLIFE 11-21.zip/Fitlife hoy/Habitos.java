/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.habitos;

/**
 *
 * @author ASUS
 */
public class Habitos {
    private String nombre;
    private String descripcion;
    private int mDiaria;
    private int pActual;
    private int streak;
    
    
    public Habitos(String nombre, String descripción, int metaDiaria){
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.mDiaria = metaDiaria;
        this.pActual = 0;
        this.streak = 0;
        
    }
    
    
public String Getnombre() {
    return nombre;

}     

public int getpActual() {
    return pActual;
    
}
 
public int getmetaDiaria() {
    return mDiaria;
    
}
 
public int getstreak() {
    return streak;
}
    
public void registrarProgreso(int cantidad) {
        this.pActual += cantidad;

        if (pActual >= mDiaria) {
            streak++;
        }
}

public void reiniciarpDia(){
    pActual = 0;
}
public String String() {
        return "Hábito: " + nombre + "\nDescripción: " + descripcion +
               "\nMeta diaria: " + mDiaria +
               "\nProgreso actual: " + pActual +
               "\nStreak: " + streak + " días\n";
}

}
